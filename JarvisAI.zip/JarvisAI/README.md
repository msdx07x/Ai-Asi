# JARVIS AI — Personal Android Voice Assistant (Kotlin)

A complete, native Kotlin Android voice assistant engineered to be compatible with **Android Studio** and buildable directly on an Android phone using **Termux** without heavy annotation processors.

## Verified Toolchain Compatibility

| Component | Version | Notes |
| --- | --- | --- |
| Android Gradle Plugin (AGP) | `8.7.3` | Requires Gradle 8.9+, JDK 17 |
| Gradle | `8.9` | Compatible with JDK 17 and Kotlin 2.0.21 |
| Kotlin | `2.0.21` | Official Android Kotlin plugin |
| JDK | `OpenJDK 17` | Installed in Termux via `pkg install openjdk-17` |
| `compileSdk` / `targetSdk` | `35` (Android 15) | `buildToolsVersion = "35.0.0"` |
| `minSdk` | `26` (Android 8.0) | Required for `AndroidKeyStore` AES-GCM & Accessibility gestures |
| Default Gemini Model | `gemini-3.5-flash-lite` | Configurable in Settings (`v1beta/models/{model}:generateContent`) |

## Features & Capability Boundaries

### Implemented Directly in App
- **Gemini AI Brain (`GeminiApiClient.kt`)**: HTTPS REST client using `x-goog-api-key` header, conversation history, timeouts, rate-limit (HTTP 429) handling, and explicit error reporting.
- **Encrypted API Key Storage (`SecureKeyStore.kt`)**: Encrypts the user's Gemini API key with `AndroidKeyStore` AES-256-GCM; excluded from Android cloud/device backups.
- **Voice Input & Output (`SpeechInputManager.kt`, `SpeechOutputManager.kt`)**: Android `SpeechRecognizer` + `TextToSpeech` with RMS audio reactivity, interruption support, language selection, speech rate, and pitch controls.
- **App Launcher (`AppLauncherManager.kt`)**: Opens installed apps (e.g., *Open YouTube*, *Open WhatsApp*, *Open Chrome*, *Open Settings*) using `PackageManager` and `<queries>` declarations.
- **YouTube Voice Search (`YouTubeSearchManager.kt`)**: Opens YouTube search intents (or HTTPS web search fallback) so the user picks a video directly.
- **Coding Assistant (`CodeResponseParser.kt`)**: Renders Markdown code fences as syntax-highlighted monospace cards with one-tap Copy buttons; never executes generated code.
- **Futuristic Dark UI (`VoiceOrbView.kt`, `MainActivity.kt`)**: Black/navy interface with customizable Cyan/Cobalt/Emerald accents, glowing audio-reactive orb, chat history (SQLite), Settings, and Permissions Guide.

### Requires User Action, Permissions, or External Services
- **Gemini API**: Requires your own Gemini API key pasted in Settings and an active internet connection.
- **Microphone & Speech Recognition**: Requires runtime `RECORD_AUDIO` permission and a device `SpeechRecognizer` provider (e.g., Google Speech Services).
- **Accessibility Automation (`JarvisAccessibilityService.kt`)**: Must be manually enabled in **Android Settings → Accessibility → Installed Apps → JARVIS AI Screen Assistant**. Consequential actions (tap, scroll, navigation) require explicit in-app confirmation and are hard-blocked on passwords, payment flows, package installers, and permission dialogs.

## Building on Android with Termux

### 1. Install Termux Packages
```bash
pkg update && pkg upgrade -y
pkg install -y openjdk-17 gradle aapt2 unzip wget termux-tools
```

### 2. Configure Environment Variables
Add these lines to `~/.bashrc` (adjust `ANDROID_HOME` to where you unpacked the Android SDK):
```bash
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
```
Reload your shell:
```bash
source ~/.bashrc
```

### 3. Install Android SDK Platform 35 & Build-Tools 35.0.0
Download the official **Command line tools only (Linux)** package from the Android Studio download page (`developer.android.com/studio#command-line-tools-only`), unzip it into `$ANDROID_HOME/cmdline-tools/latest`, and run:
```bash
yes | sdkmanager --licenses
sdkmanager "platforms;android-35" "build-tools;35.0.0"
```

### 4. Verify Environment & Build Debug APK
```bash
echo "JAVA_HOME=$JAVA_HOME"
echo "ANDROID_HOME=$ANDROID_HOME"
ls "$ANDROID_HOME/platforms/android-35" "$ANDROID_HOME/build-tools/35.0.0"
which aapt2

chmod +x termux-build.sh
./termux-build.sh
```
Or run Gradle manually:
```bash
echo "sdk.dir=$ANDROID_HOME" > local.properties
gradle assembleDebug -Pandroid.aapt2FromMavenOverride="$PREFIX/bin/aapt2" --no-daemon
```

### 5. Install the Built APK
The debug APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

Copy it to shared storage and install using Android's package installer:
```bash
termux-setup-storage
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/JarvisAI-debug.apk
```
Open your Android **Files** app → **Downloads** → tap `JarvisAI-debug.apk` (allow *Install unknown apps* for your file manager when prompted).

## Troubleshooting

- **`aapt2` Exec format error on ARM64**: Maven downloads an x86_64 `aapt2` binary. Always pass `-Pandroid.aapt2FromMavenOverride="$PREFIX/bin/aapt2"` (or add it to `~/.gradle/gradle.properties`).
- **OutOfMemoryError during Dex/R8**: Ensure `org.gradle.jvmargs=-Xmx1536m` and `--no-daemon` are used, and close background apps on phones with 4 GB RAM.
- **Gradle version mismatch**: If Termux's system `gradle` is older than `8.9`, run `gradle wrapper --gradle-version 8.9` once to generate `gradlew`, then build with `./gradlew assembleDebug -Pandroid.aapt2FromMavenOverride="$PREFIX/bin/aapt2" --no-daemon`.
- **SpeechRecognizer unavailable**: Install or enable *Speech Recognition & Synthesis from Google* from the Play Store; text chat works without it.
- **HTTP 404 from Gemini API**: Confirm the model ID in Settings is an active model (default: `gemini-3.5-flash-lite`).
