#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "=== JARVIS AI Termux Build Check ==="

if [ -z "${JAVA_HOME:-}" ]; then
  if [ -d "${PREFIX:-/data/data/com.termux/files/usr}/lib/jvm/java-17-openjdk" ]; then
    export JAVA_HOME="${PREFIX:-/data/data/com.termux/files/usr}/lib/jvm/java-17-openjdk"
  else
    echo "ERROR: JAVA_HOME is not set. Install openjdk-17 via: pkg install openjdk-17"
    exit 1
  fi
fi

if [ -z "${ANDROID_HOME:-}" ]; then
  echo "ERROR: ANDROID_HOME is not set. Point ANDROID_HOME to your Android SDK directory."
  exit 1
fi

echo "JAVA_HOME:    $JAVA_HOME"
echo "ANDROID_HOME: $ANDROID_HOME"
java -version

if [ ! -d "$ANDROID_HOME/platforms/android-35" ]; then
  echo "ERROR: Missing Android SDK Platform 35 at $ANDROID_HOME/platforms/android-35"
  echo "Install with: sdkmanager "platforms;android-35" "build-tools;35.0.0""
  exit 1
fi

if [ ! -d "$ANDROID_HOME/build-tools/35.0.0" ]; then
  echo "ERROR: Missing Android SDK Build-Tools 35.0.0 at $ANDROID_HOME/build-tools/35.0.0"
  echo "Install with: sdkmanager "build-tools;35.0.0""
  exit 1
fi

AAPT2_BIN="$(command -v aapt2 || true)"
if [ -z "$AAPT2_BIN" ]; then
  echo "ERROR: Native Termux aapt2 not found. Install with: pkg install aapt2"
  exit 1
fi
echo "Using Termux aapt2: $AAPT2_BIN"

cat > local.properties <<EOF
sdk.dir=$ANDROID_HOME
EOF

GRADLE_CMD="$(command -v gradle || true)"
if [ -z "$GRADLE_CMD" ]; then
  echo "ERROR: gradle not found. Install with: pkg install gradle"
  exit 1
fi

echo "=== Building Debug APK ==="
"$GRADLE_CMD" assembleDebug   -Pandroid.aapt2FromMavenOverride="$AAPT2_BIN"   --no-daemon

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
  echo "=== Build Succeeded ==="
  echo "APK Location: $(pwd)/$APK_PATH"
  echo "To install on your phone:"
  echo "  cp $APK_PATH /sdcard/Download/JarvisAI-debug.apk"
  echo "Then tap JarvisAI-debug.apk in your Android Files app (or run: termux-open $APK_PATH)."
else
  echo "ERROR: Build completed without producing $APK_PATH"
  exit 1
fi
