# ProGuard / R8 rules for JARVIS AI
-keepattributes SourceFile,LineNumberTable
-keep class com.jarvis.ai.model.** { *; }
-keep class com.jarvis.ai.accessibility.JarvisAccessibilityService { *; }
