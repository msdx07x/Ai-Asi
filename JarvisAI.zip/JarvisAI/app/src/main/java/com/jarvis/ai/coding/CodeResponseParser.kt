package com.jarvis.ai.coding

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.util.regex.Pattern

sealed class ResponseSegment {
    data class TextBlock(val text: String) : ResponseSegment()
    data class CodeBlock(val language: String, val code: String) : ResponseSegment()
}

data class SyntaxPalette(
    val keywordColor: Int,
    val stringColor: Int,
    val commentColor: Int,
    val numberColor: Int
)

/**
 * Splits assistant replies into prose segments and fenced code blocks,
 * with lightweight regex-based syntax highlighting for display only (never executed).
 */
object CodeResponseParser {

    private val FENCE_REGEX = Regex("```([a-zA-Z0-9_+#.-]*)\\s*\\n([\\s\\S]*?)```")

    private val KEYWORDS_PATTERN = Pattern.compile(
        "\\b(fun|val|var|class|object|interface|data|sealed|return|if|else|when|for|while|import|package|public|private|protected|void|int|String|boolean|new|try|catch|finally|def|async|await|const|let|function|export|from|true|false|null|None|True|False|html|head|body|div|script|style)\\b"
    )
    private val STRING_PATTERN = Pattern.compile(
        "(\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')"
    )
    private val COMMENT_PATTERN = Pattern.compile(
        "(//[^\\n]*|#[^\\n]*|/\\*[\\s\\S]*?\\*/)"
    )
    private val NUMBER_PATTERN = Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b")

    fun parse(content: String): List<ResponseSegment> {
        val segments = mutableListOf<ResponseSegment>()
        var cursor = 0

        for (match in FENCE_REGEX.findAll(content)) {
            if (match.range.first > cursor) {
                val prose = content.substring(cursor, match.range.first).trim()
                if (prose.isNotEmpty()) {
                    segments.add(ResponseSegment.TextBlock(prose))
                }
            }
            val lang = match.groupValues[1].trim().ifEmpty { "code" }.uppercase()
            val code = match.groupValues[2].trimEnd()
            segments.add(ResponseSegment.CodeBlock(lang, code))
            cursor = match.range.last + 1
        }

        if (cursor < content.length) {
            val tail = content.substring(cursor).trim()
            if (tail.isNotEmpty()) {
                segments.add(ResponseSegment.TextBlock(tail))
            }
        }

        if (segments.isEmpty()) {
            segments.add(ResponseSegment.TextBlock(content))
        }
        return segments
    }

    fun highlightCode(code: String, palette: SyntaxPalette): CharSequence {
        val builder = SpannableStringBuilder(code)
        applyPattern(builder, NUMBER_PATTERN, palette.numberColor)
        applyPattern(builder, KEYWORDS_PATTERN, palette.keywordColor)
        applyPattern(builder, STRING_PATTERN, palette.stringColor)
        applyPattern(builder, COMMENT_PATTERN, palette.commentColor)
        return builder
    }

    private fun applyPattern(builder: SpannableStringBuilder, pattern: Pattern, color: Int) {
        val matcher = pattern.matcher(builder)
        while (matcher.find()) {
            builder.setSpan(
                ForegroundColorSpan(color),
                matcher.start(),
                matcher.end(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }
}
