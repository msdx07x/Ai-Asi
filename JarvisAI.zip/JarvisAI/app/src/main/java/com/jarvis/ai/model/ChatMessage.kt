package com.jarvis.ai.model

enum class MessageSender {
    USER,
    ASSISTANT
}

data class ChatMessage(
    val id: Long = 0L,
    val sender: MessageSender,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)
