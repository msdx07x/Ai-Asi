package com.jarvis.ai.model

enum class ThemeAccent(val key: String, val displayName: String) {
    CYAN("cyan", "Cyber Cyan"),
    COBALT("cobalt", "Deep Cobalt"),
    EMERALD("emerald", "Emerald Matrix");

    companion object {
        fun fromKey(key: String?): ThemeAccent {
            return entries.firstOrNull { it.key == key } ?: CYAN
        }
    }
}

data class AssistantSettings(
    val assistantName: String = "JARVIS",
    val modelName: String = DEFAULT_MODEL,
    val voiceLanguageTag: String = "en-US",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val voiceResponseEnabled: Boolean = true,
    val themeAccent: ThemeAccent = ThemeAccent.CYAN,
    val saveChatHistory: Boolean = true
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    }
}
