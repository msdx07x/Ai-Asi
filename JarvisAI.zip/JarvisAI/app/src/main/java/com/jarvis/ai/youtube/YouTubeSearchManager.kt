package com.jarvis.ai.youtube

import android.content.Context
import android.content.Intent
import android.net.Uri

data class YouTubeLaunchResult(
    val opened: Boolean,
    val message: String
)

/**
 * Opens YouTube search results via supported Android intents or HTTPS search URLs.
 * Allows the user to select a video directly without scraping or unauthorized background playback.
 */
class YouTubeSearchManager(private val context: Context) {

    fun openSearch(rawQuery: String): YouTubeLaunchResult {
        val query = rawQuery.trim()
        if (query.isEmpty()) {
            return YouTubeLaunchResult(false, "Please tell me what to search on YouTube.")
        }

        val encoded = Uri.encode(query)
        val searchUri = Uri.parse("https://www.youtube.com/results?search_query=$encoded")

        // Prefer native YouTube app search intent when installed.
        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage(YOUTUBE_PACKAGE)
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            if (appIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(appIntent)
                YouTubeLaunchResult(true, "Opened YouTube search for "$query". Choose a video to play.")
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, searchUri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                YouTubeLaunchResult(true, "Opened YouTube web search for "$query". Choose a video to play.")
            }
        } catch (_: Exception) {
            YouTubeLaunchResult(false, "Unable to open YouTube or a web browser for "$query".")
        }
    }

    companion object {
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
    }
}
