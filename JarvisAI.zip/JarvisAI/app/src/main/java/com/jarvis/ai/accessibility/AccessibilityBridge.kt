package com.jarvis.ai.accessibility

import com.jarvis.ai.model.AccessibilityResult
import com.jarvis.ai.model.NavigationAction
import java.lang.ref.WeakReference

/**
 * Thread-safe bridge between the UI/CommandRouter and the user-enabled JarvisAccessibilityService.
 */
object AccessibilityBridge {

    @Volatile
    private var serviceRef: WeakReference<JarvisAccessibilityService>? = null

    fun attach(service: JarvisAccessibilityService) {
        serviceRef = WeakReference(service)
    }

    fun detach(service: JarvisAccessibilityService) {
        if (serviceRef?.get() === service) {
            serviceRef = null
        }
    }

    fun isServiceEnabled(): Boolean = serviceRef?.get() != null

    fun readCurrentScreen(): AccessibilityResult {
        val service = serviceRef?.get()
            ?: return AccessibilityResult(
                success = false,
                message = "Accessibility Service is not enabled. Open Permissions Guide to enable JARVIS AI Screen Assistant manually in Android Settings."
            )
        return service.readVisibleScreenText()
    }

    fun tapElementByLabel(label: String): AccessibilityResult {
        val service = serviceRef?.get()
            ?: return AccessibilityResult(
                success = false,
                message = "Accessibility Service is not enabled. Enable it manually in Android Settings first."
            )
        return service.performSafeTapByText(label)
    }

    fun scrollScreen(forward: Boolean): AccessibilityResult {
        val service = serviceRef?.get()
            ?: return AccessibilityResult(
                success = false,
                message = "Accessibility Service is not enabled."
            )
        return service.performSafeScroll(forward)
    }

    fun performGlobalNavigation(action: NavigationAction): AccessibilityResult {
        val service = serviceRef?.get()
            ?: return AccessibilityResult(
                success = false,
                message = "Accessibility Service is not enabled."
            )
        return service.performSafeGlobalAction(action)
    }
}
