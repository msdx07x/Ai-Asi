package com.jarvis.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.jarvis.ai.JarvisApplication
import com.jarvis.ai.R
import com.jarvis.ai.databinding.ActivityMainBinding
import com.jarvis.ai.model.AccessibilityActionRequest
import com.jarvis.ai.model.ThemeAccent
import com.jarvis.ai.voice.SpeechInputManager
import com.jarvis.ai.voice.SpeechOutputManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private lateinit var chatAdapter: ChatAdapter
    private lateinit var speechInput: SpeechInputManager
    private lateinit var speechOutput: SpeechOutputManager

    private var currentThemeAccent: ThemeAccent = ThemeAccent.CYAN
    private var isSpeaking = false

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startVoiceCapture()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is needed for voice commands. See Permissions Guide for details.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val repo = (application as JarvisApplication).settingsRepository
        currentThemeAccent = repo.loadSettings().themeAccent
        applySelectedTheme(currentThemeAccent)

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupVoiceEngines()
        setupClickListeners()
        observeState()
    }

    override fun onResume() {
        super.onResume()
        val settings = (application as JarvisApplication).settingsRepository.loadSettings()
        if (settings.themeAccent != currentThemeAccent) {
            recreate()
            return
        }
        viewModel.refreshFromStorage()
        speechOutput.applyConfig(settings.voiceLanguageTag, settings.speechRate, settings.speechPitch)
        applyOrbAccent(settings.themeAccent)
    }

    override fun onDestroy() {
        speechInput.destroy()
        speechOutput.shutdown()
        super.onDestroy()
    }

    private fun applySelectedTheme(accent: ThemeAccent) {
        val styleRes = when (accent) {
            ThemeAccent.CYAN -> R.style.Theme_JarvisAI
            ThemeAccent.COBALT -> R.style.Theme_JarvisAI_Cobalt
            ThemeAccent.EMERALD -> R.style.Theme_JarvisAI_Emerald
        }
        setTheme(styleRes)
    }

    private fun applyOrbAccent(accent: ThemeAccent) {
        val colorRes = when (accent) {
            ThemeAccent.CYAN -> R.color.accent_cyan
            ThemeAccent.COBALT -> R.color.accent_cobalt
            ThemeAccent.EMERALD -> R.color.accent_emerald
        }
        binding.voiceOrbView.setAccentColor(ContextCompat.getColor(this, colorRes))
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(viewModel.uiState.value.settings.assistantName)
        val layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.rvChat.layoutManager = layoutManager
        binding.rvChat.adapter = chatAdapter
    }

    private fun setupVoiceEngines() {
        speechOutput = SpeechOutputManager(this) { speaking ->
            isSpeaking = speaking
            binding.btnStopSpeech.visibility = if (speaking) View.VISIBLE else View.GONE
            if (speaking) {
                binding.tvStatusPill.text = getString(R.string.status_speaking)
                binding.voiceOrbView.setState(OrbState.SPEAKING)
            } else if (!speechInput.isCurrentlyListening() && !viewModel.uiState.value.isThinking) {
                binding.tvStatusPill.text = getString(R.string.status_ready)
                binding.voiceOrbView.setState(OrbState.IDLE)
            }
        }

        speechInput = SpeechInputManager(
            context = this,
            onListeningStateChanged = { listening ->
                if (listening) {
                    binding.tvStatusPill.text = getString(R.string.status_listening)
                    binding.voiceOrbView.setState(OrbState.LISTENING)
                    binding.btnMic.animate().scaleX(1.12f).scaleY(1.12f).setDuration(160).start()
                } else {
                    binding.btnMic.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160).start()
                    binding.tvLiveTranscript.visibility = View.GONE
                    if (!viewModel.uiState.value.isThinking && !isSpeaking) {
                        binding.tvStatusPill.text = getString(R.string.status_ready)
                        binding.voiceOrbView.setState(OrbState.IDLE)
                    }
                }
            },
            onRmsChanged = { level ->
                binding.voiceOrbView.updateAudioLevel(level)
            },
            onPartialResult = { partial ->
                binding.tvLiveTranscript.visibility = View.VISIBLE
                binding.tvLiveTranscript.text = partial
            },
            onFinalResult = { transcript ->
                binding.tvLiveTranscript.visibility = View.GONE
                viewModel.submitUserInput(transcript)
            },
            onError = { errorMsg ->
                binding.tvLiveTranscript.visibility = View.GONE
                Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun setupClickListeners() {
        val toggleVoice = View.OnClickListener {
            // Interruption support: stop TTS immediately when user taps mic/orb.
            if (isSpeaking) {
                speechOutput.stop()
            }
            if (speechInput.isCurrentlyListening()) {
                speechInput.stopListening()
            } else {
                requestMicAndListen()
            }
        }

        binding.btnMic.setOnClickListener(toggleVoice)
        binding.voiceOrbView.setOnClickListener(toggleVoice)

        binding.btnStopSpeech.setOnClickListener {
            speechOutput.stop()
        }

        binding.btnSend.setOnClickListener { sendTypedMessage() }
        binding.etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendTypedMessage()
                true
            } else {
                false
            }
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsGuideActivity::class.java))
        }

        binding.btnClearChat.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_chat_title)
                .setMessage(R.string.clear_chat_message)
                .setPositiveButton(R.string.action_clear) { _, _ ->
                    speechOutput.stop()
                    viewModel.clearConversation()
                }
                .setNegativeButton(R.string.action_cancel, null)
                .show()
        }

        // Quick command chips
        binding.chipOpenYoutube.setOnClickListener {
            viewModel.submitUserInput("Open YouTube")
        }
        binding.chipSearchYoutube.setOnClickListener {
            binding.etMessage.setText("Search YouTube for ")
            binding.etMessage.setSelection(binding.etMessage.text.length)
            binding.etMessage.requestFocus()
        }
        binding.chipReadScreen.setOnClickListener {
            viewModel.submitUserInput("Read screen")
        }
        binding.chipCodeHelper.setOnClickListener {
            viewModel.submitUserInput("Write a clean Python function to check if a number is prime with explanation.")
        }
    }

    private fun sendTypedMessage() {
        val text = binding.etMessage.text.toString().trim()
        if (text.isEmpty()) return
        if (isSpeaking) speechOutput.stop()
        binding.etMessage.setText("")
        viewModel.submitUserInput(text)
    }

    private fun requestMicAndListen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startVoiceCapture()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceCapture() {
        val lang = viewModel.uiState.value.settings.voiceLanguageTag
        speechInput.startListening(lang)
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvAssistantTitle.text = "${state.settings.assistantName} AI"
                        chatAdapter.updateAssistantName(state.settings.assistantName)
                        chatAdapter.submitMessages(state.messages, state.isThinking)
                        if (chatAdapter.itemCount > 0) {
                            binding.rvChat.scrollToPosition(chatAdapter.itemCount - 1)
                        }

                        if (state.isThinking) {
                            binding.tvStatusPill.text = getString(R.string.status_thinking)
                            binding.voiceOrbView.setState(OrbState.THINKING)
                        } else if (!speechInput.isCurrentlyListening() && !isSpeaking) {
                            binding.tvStatusPill.text = getString(R.string.status_ready)
                            binding.voiceOrbView.setState(OrbState.IDLE)
                        }
                    }
                }

                launch {
                    viewModel.speechEvents.collect { text ->
                        speechOutput.speak(text)
                    }
                }

                launch {
                    viewModel.confirmationRequests.collect { request ->
                        showAccessibilityConfirmationDialog(request)
                    }
                }
            }
        }
    }

    private fun showAccessibilityConfirmationDialog(request: AccessibilityActionRequest) {
        AlertDialog.Builder(this)
            .setTitle(request.title)
            .setMessage(request.description)
            .setPositiveButton(R.string.action_confirm) { _, _ ->
                viewModel.executeConfirmedAccessibilityAction(request)
            }
            .setNegativeButton(R.string.action_cancel) { _, _ ->
                viewModel.recordCancelledAccessibilityAction(request)
            }
            .show()
    }
}
