package com.jarvis.ai.command

import com.jarvis.ai.model.CommandIntent
import com.jarvis.ai.model.NavigationAction

/**
 * Classifies natural-language voice or text input into local device intents
 * (app launcher, YouTube search, accessibility actions) or Gemini AI queries.
 */
object CommandRouter {

    private val OPEN_APP_REGEX = Regex("^(?:open|launch|start)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val YOUTUBE_SEARCH_REGEX = Regex(
        "^(?:search\\s+youtube\\s+(?:for\\s+)?|youtube\\s+search\\s+(?:for\\s+)?|find\\s+(.+?)\\s+on\\s+youtube|play\\s+(.+?)\\s+on\\s+youtube)(.*)$",
        RegexOption.IGNORE_CASE
    )
    private val TAP_REGEX = Regex("^(?:tap|click|press)\\s+(?:on\\s+)?(.+)$", RegexOption.IGNORE_CASE)
    private val CODE_KEYWORDS = listOf(
        "write code", "code for", "html", "css", "javascript", "python", "kotlin", "java",
        "function", "algorithm", "script", "regex", "sql", "bug", "debug", "refactor"
    )

    fun route(rawInput: String): CommandIntent {
        val text = rawInput.trim()
        val lower = text.lowercase()

        // 1. YouTube search commands
        YOUTUBE_SEARCH_REGEX.matchEntire(text)?.let { match ->
            val extracted = listOf(match.groupValues[1], match.groupValues[2], match.groupValues[3])
                .firstOrNull { it.isNotBlank() }
                ?.trim()
                .orEmpty()
            if (extracted.isNotEmpty()) {
                return CommandIntent.YouTubeSearch(extracted)
            }
        }

        // 2. Explicit screen reading
        if (lower == "read screen" || lower == "read my screen" || lower == "what's on my screen" || lower == "whats on my screen") {
            return CommandIntent.ReadScreen
        }

        // 3. Explicit scroll / navigation commands
        if (lower == "scroll down" || lower == "scroll forward") {
            return CommandIntent.ScrollScreen(forward = true)
        }
        if (lower == "scroll up" || lower == "scroll back" || lower == "scroll backward") {
            return CommandIntent.ScrollScreen(forward = false)
        }
        if (lower == "go back" || lower == "navigate back") {
            return CommandIntent.GlobalNavigation(NavigationAction.BACK)
        }
        if (lower == "go home" || lower == "home screen") {
            return CommandIntent.GlobalNavigation(NavigationAction.HOME)
        }
        if (lower == "recent apps" || lower == "open recents") {
            return CommandIntent.GlobalNavigation(NavigationAction.RECENTS)
        }

        // 4. Explicit tap UI element command
        TAP_REGEX.matchEntire(text)?.let { match ->
            val target = match.groupValues[1].trim()
            if (target.isNotEmpty()) {
                return CommandIntent.TapElement(target)
            }
        }

        // 5. Open installed app command
        OPEN_APP_REGEX.matchEntire(text)?.let { match ->
            val appName = match.groupValues[1].trim()
            if (appName.isNotEmpty()) {
                return CommandIntent.OpenApp(appName)
            }
        }

        // 6. Fallback to Gemini AI (with coding-assistant flag when applicable)
        val isCoding = CODE_KEYWORDS.any { lower.contains(it) }
        return CommandIntent.AskGemini(prompt = text, isCodingRequest = isCoding)
    }
}
