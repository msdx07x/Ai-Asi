package com.jarvis.ai.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.ai.R
import com.jarvis.ai.coding.CodeResponseParser
import com.jarvis.ai.coding.ResponseSegment
import com.jarvis.ai.coding.SyntaxPalette
import com.jarvis.ai.model.ChatMessage
import com.jarvis.ai.model.MessageSender
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatAdapter(
    private var assistantName: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<ChatMessage>()
    private var isTyping = false
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun submitMessages(messages: List<ChatMessage>, typing: Boolean) {
        items.clear()
        items.addAll(messages)
        isTyping = typing
        notifyDataSetChanged()
    }

    fun updateAssistantName(name: String) {
        assistantName = name
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size + if (isTyping) 1 else 0

    override fun getItemViewType(position: Int): Int {
        if (isTyping && position == items.size) return VIEW_TYPE_TYPING
        return if (items[position].sender == MessageSender.USER) {
            VIEW_TYPE_USER
        } else {
            VIEW_TYPE_ASSISTANT
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_USER -> UserViewHolder(
                inflater.inflate(R.layout.item_chat_user, parent, false)
            )
            VIEW_TYPE_TYPING -> TypingViewHolder(
                inflater.inflate(R.layout.item_chat_typing, parent, false)
            )
            else -> AssistantViewHolder(
                inflater.inflate(R.layout.item_chat_assistant, parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is UserViewHolder -> holder.bind(items[position], timeFormat)
            is AssistantViewHolder -> holder.bind(items[position], assistantName, timeFormat)
            is TypingViewHolder -> holder.bind(assistantName)
        }
    }

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvMessage: TextView = itemView.findViewById(R.id.tvMessage)
        private val tvTimestamp: TextView = itemView.findViewById(R.id.tvTimestamp)

        fun bind(msg: ChatMessage, timeFormat: SimpleDateFormat) {
            tvMessage.text = msg.text
            tvTimestamp.text = timeFormat.format(Date(msg.timestampMillis))
        }
    }

    class AssistantViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvSenderLabel: TextView = itemView.findViewById(R.id.tvSenderLabel)
        private val contentContainer: LinearLayout = itemView.findViewById(R.id.contentContainer)
        private val tvTimestamp: TextView = itemView.findViewById(R.id.tvTimestamp)

        fun bind(msg: ChatMessage, assistantName: String, timeFormat: SimpleDateFormat) {
            val ctx = itemView.context
            tvSenderLabel.text = if (msg.isError) "$assistantName • NOTICE" else assistantName.uppercase()
            tvSenderLabel.setTextColor(
                ContextCompat.getColor(
                    ctx,
                    if (msg.isError) R.color.status_warn else R.color.accent_cyan
                )
            )
            tvTimestamp.text = timeFormat.format(Date(msg.timestampMillis))

            contentContainer.removeAllViews()
            val palette = SyntaxPalette(
                keywordColor = ContextCompat.getColor(ctx, R.color.code_keyword),
                stringColor = ContextCompat.getColor(ctx, R.color.code_string),
                commentColor = ContextCompat.getColor(ctx, R.color.code_comment),
                numberColor = ContextCompat.getColor(ctx, R.color.code_number)
            )

            val segments = CodeResponseParser.parse(msg.text)
            val inflater = LayoutInflater.from(ctx)

            for (segment in segments) {
                when (segment) {
                    is ResponseSegment.TextBlock -> {
                        val tv = TextView(ctx).apply {
                            text = segment.text
                            textSize = 14f
                            setTextColor(
                                ContextCompat.getColor(
                                    ctx,
                                    if (msg.isError) R.color.status_warn else R.color.text_primary
                                )
                            )
                            setTextIsSelectable(true)
                            setPadding(0, 2, 0, 4)
                        }
                        contentContainer.addView(tv)
                    }

                    is ResponseSegment.CodeBlock -> {
                        val codeView = inflater.inflate(R.layout.view_code_block, contentContainer, false)
                        val tvLang: TextView = codeView.findViewById(R.id.tvCodeLang)
                        val tvCode: TextView = codeView.findViewById(R.id.tvCodeContent)
                        val btnCopy: TextView = codeView.findViewById(R.id.btnCopyCode)

                        tvLang.text = segment.language
                        tvCode.text = CodeResponseParser.highlightCode(segment.code, palette)
                        btnCopy.setOnClickListener {
                            val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("JARVIS Code", segment.code))
                            btnCopy.text = ctx.getString(R.string.action_copied)
                            Toast.makeText(ctx, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                        }
                        contentContainer.addView(codeView)
                    }
                }
            }
        }
    }

    class TypingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTypingLabel: TextView = itemView.findViewById(R.id.tvTypingLabel)

        fun bind(assistantName: String) {
            tvTypingLabel.text = "$assistantName is thinking…"
        }
    }

    companion object {
        private const val VIEW_TYPE_USER = 1
        private const val VIEW_TYPE_ASSISTANT = 2
        private const val VIEW_TYPE_TYPING = 3
    }
}
