package com.jarvis.ai.model

sealed class CommandIntent {
    data class OpenApp(val appQuery: String) : CommandIntent()
    data class YouTubeSearch(val query: String) : CommandIntent()
    data object ReadScreen : CommandIntent()
    data class TapElement(val targetLabel: String) : CommandIntent()
    data class ScrollScreen(val forward: Boolean) : CommandIntent()
    data class GlobalNavigation(val action: NavigationAction) : CommandIntent()
    data class AskGemini(val prompt: String, val isCodingRequest: Boolean = false) : CommandIntent()
}

enum class NavigationAction {
    BACK,
    HOME,
    RECENTS
}
