package com.jarvis.ai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.jarvis.ai.model.ChatMessage
import com.jarvis.ai.model.MessageSender

class ChatHistoryDatabase(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_MESSAGES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_SENDER TEXT NOT NULL,
                $COL_TEXT TEXT NOT NULL,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_IS_ERROR INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MESSAGES")
        onCreate(db)
    }

    fun insertMessage(message: ChatMessage): Long {
        val values = ContentValues().apply {
            put(COL_SENDER, message.sender.name)
            put(COL_TEXT, message.text)
            put(COL_TIMESTAMP, message.timestampMillis)
            put(COL_IS_ERROR, if (message.isError) 1 else 0)
        }
        return writableDatabase.insert(TABLE_MESSAGES, null, values)
    }

    fun getAllMessages(limit: Int = 200): List<ChatMessage> {
        val messages = mutableListOf<ChatMessage>()
        val cursor = readableDatabase.query(
            TABLE_MESSAGES,
            arrayOf(COL_ID, COL_SENDER, COL_TEXT, COL_TIMESTAMP, COL_IS_ERROR),
            null,
            null,
            null,
            null,
            "$COL_TIMESTAMP ASC",
            limit.toString()
        )
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val senderStr = c.getString(1)
                val sender = if (senderStr == MessageSender.USER.name) {
                    MessageSender.USER
                } else {
                    MessageSender.ASSISTANT
                }
                val text = c.getString(2)
                val ts = c.getLong(3)
                val isError = c.getInt(4) == 1
                messages.add(ChatMessage(id, sender, text, ts, isError))
            }
        }
        return messages
    }

    fun clearAll() {
        writableDatabase.delete(TABLE_MESSAGES, null, null)
    }

    companion object {
        private const val DB_NAME = "jarvis_chat_history.db"
        private const val DB_VERSION = 1
        private const val TABLE_MESSAGES = "messages"
        private const val COL_ID = "id"
        private const val COL_SENDER = "sender"
        private const val COL_TEXT = "text"
        private const val COL_TIMESTAMP = "timestamp"
        private const val COL_IS_ERROR = "is_error"
    }
}
