package com.jarvis.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.jarvis.ai.JarvisApplication
import com.jarvis.ai.R
import com.jarvis.ai.accessibility.AccessibilityBridge
import com.jarvis.ai.databinding.ActivityPermissionsGuideBinding
import com.jarvis.ai.model.ThemeAccent

class PermissionsGuideActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsGuideBinding

    private val micLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        refreshStatuses()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val current = (application as JarvisApplication).settingsRepository.loadSettings()
        setTheme(
            when (current.themeAccent) {
                ThemeAccent.CYAN -> R.style.Theme_JarvisAI
                ThemeAccent.COBALT -> R.style.Theme_JarvisAI_Cobalt
                ThemeAccent.EMERALD -> R.style.Theme_JarvisAI_Emerald
            }
        )

        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsGuideBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarPermissions.setNavigationIcon(android.R.drawable.ic_menu_revert)
        binding.toolbarPermissions.setNavigationOnClickListener { finish() }

        binding.btnGrantMic.setOnClickListener {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        binding.btnOpenAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnOpenOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatuses()
    }

    private fun refreshStatuses() {
        val okColor = ContextCompat.getColor(this, R.color.status_ok)
        val warnColor = ContextCompat.getColor(this, R.color.status_warn)

        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        binding.tvMicStatus.text = if (micGranted) "Status: Granted" else "Status: Not granted"
        binding.tvMicStatus.setTextColor(if (micGranted) okColor else warnColor)

        val speechAvailable = SpeechRecognizer.isRecognitionAvailable(this)
        binding.tvSpeechServiceStatus.text = if (speechAvailable) {
            "Status: Speech recognition service detected on device"
        } else {
            "Status: No SpeechRecognizer provider detected (typed chat still works)"
        }
        binding.tvSpeechServiceStatus.setTextColor(if (speechAvailable) okColor else warnColor)

        val accEnabled = AccessibilityBridge.isServiceEnabled()
        binding.tvAccessibilityStatus.text = if (accEnabled) {
            "Status: Enabled by user"
        } else {
            "Status: Disabled (Optional — enable manually in Android Settings)"
        }
        binding.tvAccessibilityStatus.setTextColor(if (accEnabled) okColor else warnColor)

        val overlayGranted = Settings.canDrawOverlays(this)
        binding.tvOverlayStatus.text = if (overlayGranted) {
            "Status: Granted"
        } else {
            "Status: Not granted (Optional)"
        }
        binding.tvOverlayStatus.setTextColor(if (overlayGranted) okColor else warnColor)
    }
}
