package com.jarvis.ai.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings

data class LaunchResult(
    val launched: Boolean,
    val message: String
)

class AppLauncherManager(private val context: Context) {

    fun launchApp(rawQuery: String): LaunchResult {
        val query = rawQuery.trim().lowercase()
        if (query.isEmpty()) {
            return LaunchResult(false, "Please specify which app you want to open.")
        }

        // Built-in Android Settings shortcut
        if (query == "settings" || query == "android settings" || query == "device settings") {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return tryStartActivity(intent, "Settings")
        }

        val pm = context.packageManager

        // 1. Check well-known package aliases first
        val knownPackage = KNOWN_PACKAGES[query]
        if (knownPackage != null) {
            val launchIntent = pm.getLaunchIntentForPackage(knownPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val label = runCatching {
                    val info = pm.getApplicationInfo(knownPackage, 0)
                    pm.getApplicationLabel(info).toString()
                }.getOrDefault(rawQuery.trim())
                return tryStartActivity(launchIntent, label)
            }
        }

        // 2. Discover launchable apps declared via <queries> MAIN/LAUNCHER intent
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(mainIntent, 0)

        val exactMatch = resolved.firstOrNull { info ->
            info.loadLabel(pm).toString().equals(query, ignoreCase = true)
        }
        val partialMatch = exactMatch ?: resolved.firstOrNull { info ->
            info.loadLabel(pm).toString().lowercase().contains(query)
        }

        if (partialMatch != null) {
            val pkg = partialMatch.activityInfo.packageName
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val label = partialMatch.loadLabel(pm).toString()
                return tryStartActivity(launchIntent, label)
            }
        }

        return LaunchResult(
            launched = false,
            message = "Could not find an installed app matching "$rawQuery". Check that the app is installed on this device."
        )
    }

    private fun tryStartActivity(intent: Intent, displayName: String): LaunchResult {
        return try {
            context.startActivity(intent)
            LaunchResult(true, "Opening $displayName.")
        } catch (_: Exception) {
            LaunchResult(false, "Unable to launch $displayName on this device.")
        }
    }

    companion object {
        private val KNOWN_PACKAGES = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "google chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "calculator" to "com.google.android.calculator",
            "calendar" to "com.google.android.calendar"
        )
    }
}
