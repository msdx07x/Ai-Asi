package com.jarvis.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

class SpeechOutputManager(
    context: Context,
    private val onSpeakingStateChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isReady = false
    private var currentLocale: Locale = Locale.US
    private var speechRate: Float = 1.0f
    private var speechPitch: Float = 1.0f

    override fun onInit(status: Int) {
        isReady = status == TextToSpeech.SUCCESS
        if (isReady) {
            applyConfig(currentLocale.toLanguageTag(), speechRate, speechPitch)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post { onSpeakingStateChanged(true) }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post { onSpeakingStateChanged(false) }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post { onSpeakingStateChanged(false) }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    mainHandler.post { onSpeakingStateChanged(false) }
                }
            })
        }
    }

    fun applyConfig(languageTag: String, rate: Float, pitch: Float) {
        currentLocale = Locale.forLanguageTag(languageTag)
        speechRate = rate.coerceIn(0.5f, 2.0f)
        speechPitch = pitch.coerceIn(0.5f, 2.0f)
        if (isReady) {
            val langResult = tts?.setLanguage(currentLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)
        }
    }

    fun speak(text: String) {
        if (!isReady) return
        val speakable = sanitizeForSpeech(text)
        if (speakable.isEmpty()) return
        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(speakable, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        mainHandler.post { onSpeakingStateChanged(false) }
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }

    private fun sanitizeForSpeech(raw: String): String {
        // Strip fenced code blocks so TTS reads the explanation rather than raw symbols.
        val withoutCode = raw.replace(Regex("```[\\s\\S]*?```"), " Code block displayed on screen. ")
        return withoutCode
            .replace(Regex("[*_`#>]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(1200)
    }
}
