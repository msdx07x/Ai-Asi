package com.jarvis.ai.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

/**
 * Lightweight custom Canvas view rendering a glowing futuristic voice orb with
 * concentric animated rings and real-time RMS audio amplitude feedback.
 */
class VoiceOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var orbState: OrbState = OrbState.IDLE
    private var accentColor: Int = Color.parseColor("#00E5FF")
    private var phase: Float = 0f
    private var audioLevel: Float = 0f

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val animator = ValueAnimator.ofFloat(0f, (2.0 * Math.PI).toFloat()).apply {
        duration = 2800L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isRunning) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    fun setState(state: OrbState) {
        orbState = state
        animator.duration = when (state) {
            OrbState.IDLE -> 3200L
            OrbState.LISTENING -> 1400L
            OrbState.THINKING -> 1100L
            OrbState.SPEAKING -> 1600L
        }
        if (state != OrbState.LISTENING) {
            audioLevel = 0f
        }
        invalidate()
    }

    fun setAccentColor(color: Int) {
        accentColor = color
        invalidate()
    }

    fun updateAudioLevel(normalizedLevel: Float) {
        audioLevel = normalizedLevel.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val maxRadius = min(cx, cy) * 0.92f
        if (maxRadius <= 0f) return

        val wave = (sin(phase.toDouble()).toFloat() + 1f) * 0.5f
        val dynamicBoost = when (orbState) {
            OrbState.IDLE -> wave * 0.06f
            OrbState.LISTENING -> 0.08f + audioLevel * 0.22f
            OrbState.THINKING -> 0.06f + wave * 0.14f
            OrbState.SPEAKING -> 0.08f + wave * 0.16f
        }

        // Outer ambient radial glow
        val glowRadius = maxRadius * (0.78f + dynamicBoost * 0.7f)
        glowPaint.shader = RadialGradient(
            cx,
            cy,
            glowRadius,
            intArrayOf(
                applyAlpha(accentColor, 110),
                applyAlpha(accentColor, 35),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowRadius, glowPaint)

        // Outer subtle ring
        ringPaint.color = applyAlpha(accentColor, if (orbState == OrbState.IDLE) 90 else 170)
        ringPaint.strokeWidth = 2.5f
        canvas.drawCircle(cx, cy, maxRadius * (0.64f + dynamicBoost * 0.45f), ringPaint)

        // Inner rotating/pulsing ring
        ringPaint.color = applyAlpha(accentColor, 220)
        ringPaint.strokeWidth = 3.5f
        canvas.drawCircle(cx, cy, maxRadius * (0.46f + dynamicBoost * 0.35f), ringPaint)

        // Solid glowing core
        val coreRadius = maxRadius * (0.30f + dynamicBoost * 0.25f)
        corePaint.shader = RadialGradient(
            cx,
            cy,
            coreRadius,
            intArrayOf(Color.WHITE, accentColor, Color.parseColor("#0B2A4A")),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreRadius, corePaint)
    }

    private fun applyAlpha(color: Int, alpha: Int): Int {
        return Color.argb(
            alpha.coerceIn(0, 255),
            Color.red(color),
            Color.green(color),
            Color.blue(color)
        )
    }
}
