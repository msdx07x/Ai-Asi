package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.data.ChatHistoryDatabase
import com.jarvis.ai.data.SettingsRepository
import com.jarvis.ai.security.SecureKeyStore

class JarvisApplication : Application() {

    lateinit var secureKeyStore: SecureKeyStore
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var chatHistoryDatabase: ChatHistoryDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        secureKeyStore = SecureKeyStore(applicationContext)
        settingsRepository = SettingsRepository(applicationContext, secureKeyStore)
        chatHistoryDatabase = ChatHistoryDatabase(applicationContext)
    }
}
