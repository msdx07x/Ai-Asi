package com.jarvis.ai.model

sealed class AccessibilityActionRequest(
    val title: String,
    val description: String
) {
    class TapByText(val targetLabel: String) : AccessibilityActionRequest(
        title = "Confirm Tap Action",
        description = "Allow JARVIS AI to find and tap the visible UI element labeled "$targetLabel"?"
    )

    class Scroll(val forward: Boolean) : AccessibilityActionRequest(
        title = "Confirm Scroll Action",
        description = if (forward) {
            "Allow JARVIS AI to scroll down on the current screen?"
        } else {
            "Allow JARVIS AI to scroll up on the current screen?"
        }
    )

    class GlobalNav(val action: NavigationAction) : AccessibilityActionRequest(
        title = "Confirm Navigation Action",
        description = "Allow JARVIS AI to trigger system ${action.name.lowercase()} navigation?"
    )
}

data class AccessibilityResult(
    val success: Boolean,
    val message: String,
    val extractedText: String? = null
)
