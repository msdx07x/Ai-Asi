package com.jarvis.ai.data

import android.content.Context
import com.jarvis.ai.model.AssistantSettings
import com.jarvis.ai.model.ThemeAccent
import com.jarvis.ai.security.SecureKeyStore

class SettingsRepository(
    context: Context,
    private val secureKeyStore: SecureKeyStore
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): AssistantSettings {
        val name = prefs.getString(KEY_ASSISTANT_NAME, "JARVIS")?.trim().orEmpty()
        val model = prefs.getString(KEY_MODEL_NAME, AssistantSettings.DEFAULT_MODEL)?.trim().orEmpty()
        return AssistantSettings(
            assistantName = name.ifEmpty { "JARVIS" },
            modelName = model.ifEmpty { AssistantSettings.DEFAULT_MODEL },
            voiceLanguageTag = prefs.getString(KEY_LANGUAGE, "en-US") ?: "en-US",
            speechRate = prefs.getFloat(KEY_SPEECH_RATE, 1.0f).coerceIn(0.5f, 2.0f),
            speechPitch = prefs.getFloat(KEY_SPEECH_PITCH, 1.0f).coerceIn(0.5f, 2.0f),
            voiceResponseEnabled = prefs.getBoolean(KEY_VOICE_RESPONSE, true),
            themeAccent = ThemeAccent.fromKey(prefs.getString(KEY_THEME_ACCENT, ThemeAccent.CYAN.key)),
            saveChatHistory = prefs.getBoolean(KEY_SAVE_HISTORY, true)
        )
    }

    fun saveSettings(settings: AssistantSettings) {
        val cleanName = settings.assistantName.trim().ifEmpty { "JARVIS" }.take(32)
        val cleanModel = settings.modelName.trim()
            .ifEmpty { AssistantSettings.DEFAULT_MODEL }
            .replace(Regex("[^a-zA-Z0-9._-]"), "")
            .ifEmpty { AssistantSettings.DEFAULT_MODEL }

        prefs.edit()
            .putString(KEY_ASSISTANT_NAME, cleanName)
            .putString(KEY_MODEL_NAME, cleanModel)
            .putString(KEY_LANGUAGE, settings.voiceLanguageTag)
            .putFloat(KEY_SPEECH_RATE, settings.speechRate.coerceIn(0.5f, 2.0f))
            .putFloat(KEY_SPEECH_PITCH, settings.speechPitch.coerceIn(0.5f, 2.0f))
            .putBoolean(KEY_VOICE_RESPONSE, settings.voiceResponseEnabled)
            .putString(KEY_THEME_ACCENT, settings.themeAccent.key)
            .putBoolean(KEY_SAVE_HISTORY, settings.saveChatHistory)
            .apply()
    }

    fun saveApiKey(apiKey: String): Boolean = secureKeyStore.saveApiKey(apiKey)

    fun getApiKey(): String? = secureKeyStore.getApiKey()

    fun hasApiKey(): Boolean = secureKeyStore.hasApiKey()

    fun clearApiKey() = secureKeyStore.clearApiKey()

    companion object {
        private const val PREFS_NAME = "jarvis_settings"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_MODEL_NAME = "model_name"
        private const val KEY_LANGUAGE = "voice_language"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_VOICE_RESPONSE = "voice_response_enabled"
        private const val KEY_THEME_ACCENT = "theme_accent"
        private const val KEY_SAVE_HISTORY = "save_chat_history"
    }
}
