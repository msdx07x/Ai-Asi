package com.jarvis.ai.network

import com.jarvis.ai.model.ChatMessage
import com.jarvis.ai.model.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.nio.charset.StandardCharsets

sealed class GeminiResult {
    data class Success(val text: String) : GeminiResult()
    data class Failure(
        val userMessage: String,
        val httpCode: Int? = null,
        val isRateLimited: Boolean = false
    ) : GeminiResult()
}

/**
 * Native HTTPS REST client for the Google Gemini generateContent API.
 * Uses x-goog-api-key header (never query strings) and omits deprecated sampling fields.
 */
class GeminiApiClient {

    suspend fun generateReply(
        apiKey: String,
        modelName: String,
        assistantName: String,
        history: List<ChatMessage>,
        latestUserPrompt: String,
        isCodingRequest: Boolean
    ): GeminiResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return@withContext GeminiResult.Failure(
                "Gemini API key is not configured. Open Settings to add your key."
            )
        }

        val cleanModel = modelName.trim().replace(Regex("[^a-zA-Z0-9._-]"), "")
        if (cleanModel.isEmpty()) {
            return@withContext GeminiResult.Failure("Invalid Gemini model name in Settings.")
        }

        val endpoint = "$BASE_URL/$cleanModel:generateContent"
        var connection: HttpURLConnection? = null

        try {
            val url = URL(endpoint)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                doInput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-goog-api-key", cleanKey)
            }

            val payload = buildRequestPayload(
                assistantName = assistantName,
                history = history,
                latestUserPrompt = latestUserPrompt,
                isCodingRequest = isCodingRequest
            )

            OutputStreamWriter(connection.outputStream, StandardCharsets.UTF_8).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.let { input ->
                BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).use { it.readText() }
            }.orEmpty()

            if (statusCode in 200..299) {
                parseSuccessResponse(body)
            } else {
                parseErrorResponse(statusCode, body, connection.getHeaderField("Retry-After"))
            }
        } catch (_: SocketTimeoutException) {
            GeminiResult.Failure("Request timed out while waiting for Gemini. Check your network and try again.")
        } catch (_: UnknownHostException) {
            GeminiResult.Failure("No internet connection. Unable to reach Gemini API.")
        } catch (ex: Exception) {
            GeminiResult.Failure("Network error: ${ex.localizedMessage ?: "Unable to complete request."}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun buildRequestPayload(
        assistantName: String,
        history: List<ChatMessage>,
        latestUserPrompt: String,
        isCodingRequest: Boolean
    ): JSONObject {
        val systemText = buildString {
            append("You are $assistantName, a helpful, concise personal Android AI assistant. ")
            append("Keep spoken answers clear and practical. ")
            if (isCodingRequest) {
                append("The user is asking for code. Provide clean, complete, well-formatted code inside fenced markdown blocks with the language tag (such as ```kotlin, ```python, ```html, ```css, ```javascript, or ```java), followed by a concise explanation. ")
            }
            append("Never claim you executed code or performed a device action unless the app explicitly reported that it succeeded.")
        }

        val systemInstruction = JSONObject().apply {
            put("parts", JSONArray().put(JSONObject().put("text", systemText)))
        }

        // Build clean alternating conversation turns (excluding error bubbles) and always end with a user turn.
        val contents = JSONArray()
        val recentHistory = history
            .filter { !it.isError && it.text.isNotBlank() }
            .takeLast(MAX_HISTORY_TURNS)

        var lastRole: String? = null
        for (msg in recentHistory) {
            val role = if (msg.sender == MessageSender.USER) "user" else "model"
            if (contents.length() == 0 && role != "user") continue
            if (role == lastRole) continue
            contents.put(
                JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                }
            )
            lastRole = role
        }

        // Ensure the final turn is always the current user prompt (Gemini 3.5+ rejects trailing model turns).
        val needsAppendUser = lastRole != "user" ||
            recentHistory.lastOrNull()?.text?.trim() != latestUserPrompt.trim()
        if (needsAppendUser) {
            if (lastRole == "user" && contents.length() > 0) {
                contents.remove(contents.length() - 1)
            }
            contents.put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", latestUserPrompt.trim())))
                }
            )
        }

        return JSONObject().apply {
            put("systemInstruction", systemInstruction)
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 2048)
            })
        }
    }

    private fun parseSuccessResponse(body: String): GeminiResult {
        return try {
            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                val blockReason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                val msg = if (blockReason.isNotEmpty()) {
                    "Gemini declined to answer this prompt (reason: $blockReason)."
                } else {
                    "Gemini returned an empty response."
                }
                return GeminiResult.Failure(msg)
            }

            val firstCandidate = candidates.getJSONObject(0)
            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")
            val textBuilder = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val partText = parts.optJSONObject(i)?.optString("text").orEmpty()
                    if (partText.isNotEmpty()) {
                        if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                        textBuilder.append(partText)
                    }
                }
            }

            val finalText = textBuilder.toString().trim()
            if (finalText.isEmpty()) {
                val finishReason = firstCandidate.optString("finishReason", "UNKNOWN")
                GeminiResult.Failure("No text was returned by Gemini (finishReason: $finishReason).")
            } else {
                GeminiResult.Success(finalText)
            }
        } catch (_: Exception) {
            GeminiResult.Failure("Failed to parse Gemini API response.")
        }
    }

    private fun parseErrorResponse(statusCode: Int, body: String, retryAfter: String?): GeminiResult {
        val apiMessage = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Exception) {
            ""
        }

        return when (statusCode) {
            400 -> GeminiResult.Failure(
                "Bad request (400): ${apiMessage.ifEmpty { "Check your model name or prompt format." }}",
                httpCode = 400
            )
            401, 403 -> GeminiResult.Failure(
                "Authentication failed ($statusCode). Verify your Gemini API key in Settings.",
                httpCode = statusCode
            )
            404 -> GeminiResult.Failure(
                "Model not found (404). Update the Gemini model ID in Settings (e.g. gemini-3.5-flash-lite).",
                httpCode = 404
            )
            429 -> {
                val retryHint = retryAfter?.let { " Retry after ${it}s." } ?: " Please wait a moment and try again."
                GeminiResult.Failure(
                    "Rate limit reached (429).$retryHint",
                    httpCode = 429,
                    isRateLimited = true
                )
            }
            in 500..599 -> GeminiResult.Failure(
                "Gemini service is temporarily unavailable ($statusCode). Please try again shortly.",
                httpCode = statusCode
            )
            else -> GeminiResult.Failure(
                "Gemini API error ($statusCode): ${apiMessage.ifEmpty { "Unexpected response." }}",
                httpCode = statusCode
            )
        }
    }

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 30_000
        private const val MAX_HISTORY_TURNS = 16
    }
}
