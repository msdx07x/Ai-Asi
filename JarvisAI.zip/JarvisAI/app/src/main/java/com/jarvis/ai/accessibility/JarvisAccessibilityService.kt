package com.jarvis.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.ai.model.AccessibilityResult
import com.jarvis.ai.model.NavigationAction

/**
 * User-enabled AccessibilityService with strict security guardrails.
 * - Never reads or uploads screen content in the background.
 * - Prefers semantic AccessibilityNodeInfo actions over coordinate taps.
 * - Blocks automation on password fields, permission dialogs, package installers, and payment flows.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityBridge.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally passive: never capture or upload screen data automatically.
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        AccessibilityBridge.detach(this)
        super.onDestroy()
    }

    fun readVisibleScreenText(): AccessibilityResult {
        val root = rootInActiveWindow
            ?: return AccessibilityResult(false, "No active window is accessible right now.")

        val pkg = root.packageName?.toString().orEmpty()
        if (isBlockedSecurityPackage(pkg)) {
            return AccessibilityResult(
                success = false,
                message = "Blocked by safety policy: cannot read system security or permission dialogs."
            )
        }

        val lines = LinkedHashSet<String>()
        collectVisibleText(root, lines, maxItems = 60)

        return if (lines.isEmpty()) {
            AccessibilityResult(false, "No readable text elements were exposed on the current screen.")
        } else {
            val combined = lines.joinToString(separator = "\n")
            AccessibilityResult(
                success = true,
                message = "Visible screen text:\n$combined",
                extractedText = combined
            )
        }
    }

    fun performSafeTapByText(targetLabel: String): AccessibilityResult {
        val query = targetLabel.trim()
        if (query.isEmpty()) {
            return AccessibilityResult(false, "Please specify which visible button or label to tap.")
        }

        if (containsBlockedKeyword(query)) {
            return AccessibilityResult(
                success = false,
                message = "Blocked by safety policy: JARVIS AI will not automate payments, permissions, installations, or security confirmations."
            )
        }

        val root = rootInActiveWindow
            ?: return AccessibilityResult(false, "No active screen window is available to interact with.")

        val pkg = root.packageName?.toString().orEmpty()
        if (isBlockedSecurityPackage(pkg)) {
            return AccessibilityResult(
                success = false,
                message = "Blocked by safety policy: automation is disabled on system security, authentication, and permission screens."
            )
        }

        val candidate = findBestMatchingNode(root, query)
            ?: return AccessibilityResult(
                success = false,
                message = "Could not find a visible UI element matching "$query"."
            )

        if (candidate.isPassword || containsBlockedKeyword(candidate.text?.toString().orEmpty()) ||
            containsBlockedKeyword(candidate.contentDescription?.toString().orEmpty())
        ) {
            return AccessibilityResult(
                success = false,
                message = "Blocked by safety policy: cannot interact with password fields or sensitive confirmation controls."
            )
        }

        // Prefer semantic node action (walking up to clickable parent if needed).
        val clickableNode = findClickableAncestor(candidate)
        if (clickableNode != null && clickableNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return AccessibilityResult(true, "Tapped "$query" using accessibility node action.")
        }

        // Fallback to centered tap gesture only on verified visible bounds.
        val bounds = Rect()
        candidate.getBoundsInScreen(bounds)
        if (!bounds.isEmpty && bounds.centerX() > 0 && bounds.centerY() > 0) {
            val dispatched = dispatchTapGesture(bounds.centerX().toFloat(), bounds.centerY().toFloat())
            return if (dispatched) {
                AccessibilityResult(true, "Tapped "$query" via accessibility gesture.")
            } else {
                AccessibilityResult(false, "Found "$query", but the gesture could not be dispatched.")
            }
        }

        return AccessibilityResult(false, "Found "$query", but it does not expose a clickable action.")
    }

    fun performSafeScroll(forward: Boolean): AccessibilityResult {
        val root = rootInActiveWindow
            ?: return AccessibilityResult(false, "No active window available to scroll.")

        if (isBlockedSecurityPackage(root.packageName?.toString().orEmpty())) {
            return AccessibilityResult(false, "Blocked by safety policy on system security screens.")
        }

        val scrollable = findFirstScrollableNode(root)
            ?: return AccessibilityResult(false, "No scrollable container found on the current screen.")

        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        val ok = scrollable.performAction(action)
        return if (ok) {
            AccessibilityResult(true, if (forward) "Scrolled forward." else "Scrolled backward.")
        } else {
            AccessibilityResult(false, "Could not scroll any further in that direction.")
        }
    }

    fun performSafeGlobalAction(action: NavigationAction): AccessibilityResult {
        val globalId = when (action) {
            NavigationAction.BACK -> GLOBAL_ACTION_BACK
            NavigationAction.HOME -> GLOBAL_ACTION_HOME
            NavigationAction.RECENTS -> GLOBAL_ACTION_RECENTS
        }
        val ok = performGlobalAction(globalId)
        return if (ok) {
            AccessibilityResult(true, "Performed ${action.name.lowercase()} navigation.")
        } else {
            AccessibilityResult(false, "Unable to perform ${action.name.lowercase()} navigation.")
        }
    }

    private fun collectVisibleText(
        node: AccessibilityNodeInfo,
        out: MutableSet<String>,
        maxItems: Int
    ) {
        if (out.size >= maxItems || !node.isVisibleToUser) return
        if (!node.isPassword) {
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) out.add(text)
            else if (desc.isNotEmpty()) out.add(desc)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectVisibleText(child, out, maxItems)
        }
    }

    private fun findBestMatchingNode(
        root: AccessibilityNodeInfo,
        query: String
    ): AccessibilityNodeInfo? {
        val directMatches = root.findAccessibilityNodeInfosByText(query)
        val visibleDirect = directMatches?.firstOrNull { it.isVisibleToUser }
        if (visibleDirect != null) return visibleDirect

        return searchByDescriptionOrText(root, query.lowercase())
    }

    private fun searchByDescriptionOrText(
        node: AccessibilityNodeInfo,
        queryLower: String
    ): AccessibilityNodeInfo? {
        if (node.isVisibleToUser) {
            val text = node.text?.toString()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
            if (text.contains(queryLower) || desc.contains(queryLower)) {
                return node
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = searchByDescriptionOrText(child, queryLower)
            if (match != null) return match
        }
        return null
    }

    private fun findClickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var current = node
        var depth = 0
        while (current != null && depth < 6) {
            if (current.isClickable && current.isEnabled) return current
            current = current.parent
            depth++
        }
        return null
    }

    private fun findFirstScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFirstScrollableNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun dispatchTapGesture(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun isBlockedSecurityPackage(packageName: String): Boolean {
        val lower = packageName.lowercase()
        return BLOCKED_PACKAGES.any { lower.contains(it) }
    }

    private fun containsBlockedKeyword(text: String): Boolean {
        val lower = text.lowercase()
        return BLOCKED_KEYWORDS.any { lower.contains(it) }
    }

    companion object {
        private val BLOCKED_PACKAGES = listOf(
            "permissioncontroller",
            "packageinstaller",
            "biometric",
            "keyguard",
            "credential",
            "wallet",
            "google.android.gms.auth"
        )

        private val BLOCKED_KEYWORDS = listOf(
            "password",
            "passcode",
            "pin code",
            "pay now",
            "confirm payment",
            "purchase",
            "checkout",
            "authorize",
            "allow all",
            "grant permission",
            "uninstall",
            "delete account",
            "factory reset"
        )
    }
}
