package com.jarvis.ai.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.ai.JarvisApplication
import com.jarvis.ai.R
import com.jarvis.ai.databinding.ActivitySettingsBinding
import com.jarvis.ai.model.AssistantSettings
import com.jarvis.ai.model.ThemeAccent
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val languageOptions = listOf(
        "en-US" to "English (US)",
        "en-IN" to "English (India)",
        "en-GB" to "English (UK)",
        "hi-IN" to "Hindi (India)",
        "es-ES" to "Spanish (Spain)",
        "fr-FR" to "French",
        "de-DE" to "German",
        "ja-JP" to "Japanese"
    )

    private val themeOptions = ThemeAccent.entries

    override fun onCreate(savedInstanceState: Bundle?) {
        val app = application as JarvisApplication
        val current = app.settingsRepository.loadSettings()
        setTheme(
            when (current.themeAccent) {
                ThemeAccent.CYAN -> R.style.Theme_JarvisAI
                ThemeAccent.COBALT -> R.style.Theme_JarvisAI_Cobalt
                ThemeAccent.EMERALD -> R.style.Theme_JarvisAI_Emerald
            }
        )

        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarSettings.setNavigationIcon(android.R.drawable.ic_menu_revert)
        binding.toolbarSettings.setNavigationOnClickListener { finish() }

        setupSpinners()
        populateCurrentValues(current)
        setupListeners()
    }

    private fun setupSpinners() {
        val langLabels = languageOptions.map { it.second }
        binding.spinnerLanguage.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            langLabels
        )

        val themeLabels = themeOptions.map { it.displayName }
        binding.spinnerTheme.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            themeLabels
        )
    }

    private fun populateCurrentValues(settings: AssistantSettings) {
        val repo = (application as JarvisApplication).settingsRepository
        binding.etAssistantName.setText(settings.assistantName)
        binding.etModelName.setText(settings.modelName)
        binding.switchVoiceResponse.isChecked = settings.voiceResponseEnabled
        binding.switchSaveHistory.isChecked = settings.saveChatHistory

        updateApiKeyStatusText(repo.hasApiKey())

        val langIndex = languageOptions.indexOfFirst { it.first == settings.voiceLanguageTag }
        if (langIndex >= 0) binding.spinnerLanguage.setSelection(langIndex)

        val themeIndex = themeOptions.indexOf(settings.themeAccent)
        if (themeIndex >= 0) binding.spinnerTheme.setSelection(themeIndex)

        val rateProgress = ((settings.speechRate - 0.5f) * 10f).toInt().coerceIn(0, 15)
        binding.seekSpeechRate.progress = rateProgress
        binding.tvSpeechRateLabel.text = String.format(Locale.US, "Speech Rate: %.1fx", progressToFactor(rateProgress))

        val pitchProgress = ((settings.speechPitch - 0.5f) * 10f).toInt().coerceIn(0, 15)
        binding.seekPitch.progress = pitchProgress
        binding.tvPitchLabel.text = String.format(Locale.US, "Voice Pitch: %.1fx", progressToFactor(pitchProgress))
    }

    private fun setupListeners() {
        val app = application as JarvisApplication
        val repo = app.settingsRepository

        binding.seekSpeechRate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvSpeechRateLabel.text =
                    String.format(Locale.US, "Speech Rate: %.1fx", progressToFactor(progress))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.seekPitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvPitchLabel.text =
                    String.format(Locale.US, "Voice Pitch: %.1fx", progressToFactor(progress))
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        binding.btnClearApiKey.setOnClickListener {
            repo.clearApiKey()
            binding.etApiKey.setText("")
            updateApiKeyStatusText(false)
            Toast.makeText(this, "Stored API key removed.", Toast.LENGTH_SHORT).show()
        }

        binding.btnClearHistorySettings.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_chat_title)
                .setMessage(R.string.clear_chat_message)
                .setPositiveButton(R.string.action_clear) { _, _ ->
                    app.chatHistoryDatabase.clearAll()
                    Toast.makeText(this, "Chat history cleared.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(R.string.action_cancel, null)
                .show()
        }

        binding.btnSaveSettings.setOnClickListener {
            val newApiKey = binding.etApiKey.text.toString().trim()
            if (newApiKey.isNotEmpty()) {
                val saved = repo.saveApiKey(newApiKey)
                if (!saved) {
                    Toast.makeText(this, "Failed to encrypt API key in Android Keystore.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                binding.etApiKey.setText("")
            }

            val updated = AssistantSettings(
                assistantName = binding.etAssistantName.text.toString().trim().ifEmpty { "JARVIS" },
                modelName = binding.etModelName.text.toString().trim().ifEmpty { AssistantSettings.DEFAULT_MODEL },
                voiceLanguageTag = languageOptions[binding.spinnerLanguage.selectedItemPosition].first,
                speechRate = progressToFactor(binding.seekSpeechRate.progress),
                speechPitch = progressToFactor(binding.seekPitch.progress),
                voiceResponseEnabled = binding.switchVoiceResponse.isChecked,
                themeAccent = themeOptions[binding.spinnerTheme.selectedItemPosition],
                saveChatHistory = binding.switchSaveHistory.isChecked
            )
            repo.saveSettings(updated)
            Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun updateApiKeyStatusText(hasKey: Boolean) {
        binding.tvApiKeyStatus.text = if (hasKey) {
            "Status: API key encrypted and stored on-device (paste a new key below to replace)."
        } else {
            "Status: No API key stored yet."
        }
    }

    private fun progressToFactor(progress: Int): Float = 0.5f + (progress * 0.1f)
}
