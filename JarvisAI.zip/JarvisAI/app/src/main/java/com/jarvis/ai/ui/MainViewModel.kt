package com.jarvis.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.JarvisApplication
import com.jarvis.ai.accessibility.AccessibilityBridge
import com.jarvis.ai.command.CommandRouter
import com.jarvis.ai.launcher.AppLauncherManager
import com.jarvis.ai.model.AccessibilityActionRequest
import com.jarvis.ai.model.AssistantSettings
import com.jarvis.ai.model.ChatMessage
import com.jarvis.ai.model.CommandIntent
import com.jarvis.ai.model.MessageSender
import com.jarvis.ai.network.GeminiApiClient
import com.jarvis.ai.network.GeminiResult
import com.jarvis.ai.youtube.YouTubeSearchManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MainUiState(
    val settings: AssistantSettings = AssistantSettings(),
    val messages: List<ChatMessage> = emptyList(),
    val isThinking: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as JarvisApplication
    private val settingsRepo = app.settingsRepository
    private val historyDb = app.chatHistoryDatabase
    private val geminiClient = GeminiApiClient()
    private val appLauncher = AppLauncherManager(application.applicationContext)
    private val youTubeSearch = YouTubeSearchManager(application.applicationContext)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _speechEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val speechEvents: SharedFlow<String> = _speechEvents.asSharedFlow()

    private val _confirmationRequests = MutableSharedFlow<AccessibilityActionRequest>(extraBufferCapacity = 2)
    val confirmationRequests: SharedFlow<AccessibilityActionRequest> = _confirmationRequests.asSharedFlow()

    init {
        refreshFromStorage()
    }

    fun refreshFromStorage() {
        val settings = settingsRepo.loadSettings()
        val stored = if (settings.saveChatHistory) historyDb.getAllMessages() else _uiState.value.messages
        val initialMessages = if (stored.isEmpty()) {
            listOf(
                ChatMessage(
                    sender = MessageSender.ASSISTANT,
                    text = "Hello! I am ${settings.assistantName}. Tap the glowing orb to speak, type a coding request, or say "Open YouTube"."
                )
            )
        } else {
            stored
        }
        _uiState.value = _uiState.value.copy(settings = settings, messages = initialMessages)
    }

    fun submitUserInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isEmpty() || _uiState.value.isThinking) return

        appendMessage(ChatMessage(sender = MessageSender.USER, text = input))

        when (val intent = CommandRouter.route(input)) {
            is CommandIntent.OpenApp -> {
                val result = appLauncher.launchApp(intent.appQuery)
                respondLocally(result.message, isError = !result.launched)
            }

            is CommandIntent.YouTubeSearch -> {
                val result = youTubeSearch.openSearch(intent.query)
                respondLocally(result.message, isError = !result.opened)
            }

            is CommandIntent.ReadScreen -> {
                val result = AccessibilityBridge.readCurrentScreen()
                respondLocally(result.message, isError = !result.success)
            }

            is CommandIntent.TapElement -> {
                if (!AccessibilityBridge.isServiceEnabled()) {
                    respondLocally(
                        "Accessibility Service is disabled. Enable JARVIS AI Screen Assistant manually in Android Settings (see Permissions Guide).",
                        isError = true
                    )
                } else {
                    _confirmationRequests.tryEmit(AccessibilityActionRequest.TapByText(intent.targetLabel))
                }
            }

            is CommandIntent.ScrollScreen -> {
                if (!AccessibilityBridge.isServiceEnabled()) {
                    respondLocally(
                        "Accessibility Service is disabled. Enable it manually in Android Settings first.",
                        isError = true
                    )
                } else {
                    _confirmationRequests.tryEmit(AccessibilityActionRequest.Scroll(intent.forward))
                }
            }

            is CommandIntent.GlobalNavigation -> {
                if (!AccessibilityBridge.isServiceEnabled()) {
                    respondLocally(
                        "Accessibility Service is disabled. Enable it manually in Android Settings first.",
                        isError = true
                    )
                } else {
                    _confirmationRequests.tryEmit(AccessibilityActionRequest.GlobalNav(intent.action))
                }
            }

            is CommandIntent.AskGemini -> {
                queryGemini(intent.prompt, intent.isCodingRequest)
            }
        }
    }

    fun executeConfirmedAccessibilityAction(request: AccessibilityActionRequest) {
        val result = when (request) {
            is AccessibilityActionRequest.TapByText -> AccessibilityBridge.tapElementByLabel(request.targetLabel)
            is AccessibilityActionRequest.Scroll -> AccessibilityBridge.scrollScreen(request.forward)
            is AccessibilityActionRequest.GlobalNav -> AccessibilityBridge.performGlobalNavigation(request.action)
        }
        respondLocally(result.message, isError = !result.success)
    }

    fun recordCancelledAccessibilityAction(request: AccessibilityActionRequest) {
        respondLocally("Cancelled: ${request.title}.", isError = false)
    }

    fun clearConversation() {
        historyDb.clearAll()
        val name = _uiState.value.settings.assistantName
        _uiState.value = _uiState.value.copy(
            messages = listOf(
                ChatMessage(
                    sender = MessageSender.ASSISTANT,
                    text = "Conversation cleared. How can $name help?"
                )
            ),
            isThinking = false
        )
    }

    private fun queryGemini(prompt: String, isCodingRequest: Boolean) {
        val settings = settingsRepo.loadSettings()
        val apiKey = settingsRepo.getApiKey().orEmpty()

        if (apiKey.isBlank()) {
            respondLocally(
                "No Gemini API key saved yet. Tap the Settings icon at the top right to paste and securely store your Gemini API key.",
                isError = true
            )
            return
        }

        val snapshotHistory = _uiState.value.messages
        _uiState.value = _uiState.value.copy(isThinking = true)

        viewModelScope.launch {
            val result = geminiClient.generateReply(
                apiKey = apiKey,
                modelName = settings.modelName,
                assistantName = settings.assistantName,
                history = snapshotHistory,
                latestUserPrompt = prompt,
                isCodingRequest = isCodingRequest
            )
            _uiState.value = _uiState.value.copy(isThinking = false)

            when (result) {
                is GeminiResult.Success -> {
                    respondLocally(result.text, isError = false)
                }
                is GeminiResult.Failure -> {
                    respondLocally(result.userMessage, isError = true)
                }
            }
        }
    }

    private fun respondLocally(message: String, isError: Boolean) {
        appendMessage(ChatMessage(sender = MessageSender.ASSISTANT, text = message, isError = isError))
        if (_uiState.value.settings.voiceResponseEnabled) {
            _speechEvents.tryEmit(message)
        }
    }

    private fun appendMessage(message: ChatMessage) {
        val savedId = if (_uiState.value.settings.saveChatHistory) {
            historyDb.insertMessage(message)
        } else {
            System.currentTimeMillis()
        }
        val persisted = message.copy(id = savedId)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + persisted)
    }
}
